function FourthAnimation (){
    
    const a = document.getElementById("log_in_message");
    
    setTimeout(() => {
        a.style.opacity=0;
        setTimeout(()=>{
            a.style.display="none";
        },1500)
        
    
    }, 1500);
    
    
}
function getFN(){
    const a = document.getElementById("welcome_fn");
    const b = localStorage.getItem('first_name');
    a.textContent = `${b}!`;
    a.style.paddingLeft = "15px";
}

function complete_profile(){
    const fn = localStorage.getItem('first_name');
    const ln = localStorage.getItem('last_name');
    const email = localStorage.getItem('email');
    const username = localStorage.getItem('username');
    const workplace = localStorage.getItem('workplace');
    const a = document.getElementById("profilename_title");
    a.textContent=`${fn} ${ln}`;
    const b = document.getElementById("username_profile");
    b.textContent=`Username: ${username}`;
    const c = document.getElementById("email_profile");
    c.textContent=`Email: ${email}`;
    const d = document.getElementById("workplace_profile");
    d.textContent=`Workplace: ${workplace}`;

}

document.addEventListener("DOMContentLoaded", function() {
    console.log("JS2 loaded");
    FourthAnimation();
    getFN();
    complete_profile();

    
});