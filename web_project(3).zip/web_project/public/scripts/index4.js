

function get_car_info(id_) {
                 
        const data = {
            id_: id_,
        };
    
        
        fetch('/car_details', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data) 
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Car found successfully!') {
                localStorage.setItem('cc', data.cc);
                console.log(localStorage.getItem('cc'));
                localStorage.setItem('color', data.color);
                console.log(localStorage.getItem('color'));
                localStorage.setItem('type', data.type);
                console.log(localStorage.getItem('type'));
                localStorage.setItem('model_name', data.model_name);
                console.log(localStorage.getItem('model_name'));
                localStorage.setItem('average_consumpt', data.average_consumpt);
                console.log(localStorage.getItem('average_consumpt'));
                localStorage.setItem('class_', data.class_);
                console.log(localStorage.getItem('class_'));

                }
        })
        
    }

    function details_form(){
    const cc = localStorage.getItem('cc');
    const type = localStorage.getItem('type');
    const color = localStorage.getItem('color');
    const model_car = localStorage.getItem('model_name');
    const avg_cons = localStorage.getItem('average_consumpt');
    const class_ = localStorage.getItem('class_');
    const a = document.getElementById("class_car");
    a.textContent=`Class: ${class_}`;
    const b = document.getElementById("model_car");
    b.textContent=`Car Name: ${model_car}`;
    const c = document.getElementById("model_type");
    c.textContent=`Type: ${type}`;
    const d = document.getElementById("car_color");
    d.textContent=`Color: ${color}`;
    const e = document.getElementById("car_cc");
    e.textContent=`CC: ${cc}`;
    const f = document.getElementById("avg_cons_car");
    f.textContent=`Avg Consumption: ${avg_cons}`;

}


function complete_contract() {
    const start_date = document.getElementById('start_date_form').value;
    const end_date = document.getElementById('end_date_form').value;
    const pick_up_loc = document.getElementById('pickup_loc').value;
    const drop_off_loc = document.getElementById('dropoff_loc').value;

    const data = {
        startdate: start_date,
        enddate: end_date,
        pickup_loc: pick_up_loc,
        dropoff_loc: drop_off_loc,
        user_id: localStorage.getItem('user_id'),
        car_id: localStorage.getItem('car_id')
    };
    console.log("Sending to backend:", data);
    const formContainer = document.getElementById("form_container");

    fetch('/car_details', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        return response.json().then(data => {
            if (!response.ok) {
                const errMessage = data.error || 'Something went wrong.';
                alert("Bad Dog! " + errMessage); 
                throw new Error(data.error || 'Unknown error occurred');
            }
            return data;
        });
    })
    .then(data => {
        if (data.message === 'Contract created successfully!') {
            localStorage.setItem('start_date', start_date);
            localStorage.setItem('end_date', end_date);
            localStorage.setItem('pick_up', pick_up_loc);
            localStorage.setItem('drop_off', drop_off_loc);

            window.location.href = '/profile';
        }
    })
    .catch(error => {
        console.error('Error Contract:', error);

        
        const divmessage = document.createElement('div');
        const errormessage = document.createElement('p');
        errormessage.textContent = error.message;
        errormessage.style.color = 'red';
        errormessage.style.textAlign = 'center';
        divmessage.style.opacity = 0;
        divmessage.style.transition = 'opacity 800ms ease-in-out';
        divmessage.appendChild(errormessage);
        formContainer.appendChild(divmessage);

        setTimeout(() => {
            divmessage.style.opacity = 1;
            setTimeout(() => {
                divmessage.style.opacity = 0;
                setTimeout(() => {
                    formContainer.removeChild(divmessage);
                }, 800);
            }, 2000);
        }, 50);
    });
}
function log_out(){
    const log_out = 1;
    const data = {
        
        log_out: log_out

    };
    fetch('/car_details', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data) 
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Logout successful!') {
            localStorage.clear();
            window.location.href = '/';
            }

    })

}


        document.addEventListener("DOMContentLoaded", function(){
    
            console.log("js4");
    
            const button11=document.getElementById("log_out_nav");
            button11.addEventListener("click",function(){
                console.log("log out");
                log_out();
            })
            const button12=document.getElementById("Rent_a_car_nav");
            button12.addEventListener("click",function(){
                window.location.href = '/rent_car';
            })
        
            const button13=document.getElementById("myprofile_nav");
            button13.addEventListener("click",function(){
            
                window.location.href = '/profile';
            })
            const button15=document.getElementById("submit_btn2");
            button15.addEventListener("click",function(){
                console.log("button clicked");
                complete_contract();
            })
            const button14=document.getElementById("rent_the_car");
            button14.addEventListener("click",function(){
            
                window.location.href = '/car_details';
            })
        
           
        })